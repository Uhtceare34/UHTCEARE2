@echo off
cd /d "%~dp0"
where msedge.exe >nul 2>nul
if %errorlevel%==0 (
  start "" msedge.exe "%~dp0edit.html"
  exit /b
)
where chrome.exe >nul 2>nul
if %errorlevel%==0 (
  start "" chrome.exe "%~dp0edit.html"
  exit /b
)
start "" "%~dp0edit.html"
