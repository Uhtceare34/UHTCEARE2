let dirHandle = null;
let entries = [];
let current = null;
let selectedCover = null;
let selectedPhotos = [];
let msgTimer = null;

const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const CAT_NAMES = {
  journal:"我今天发生了什么。",
  notes:"我刚刚想到什么。",
  novel:"我创造了什么。",
  photographs:"我看见了什么。",
  music:"我听见了什么，以及我如何理解它。"
};

function showMsg(text, err=false){
  const el=$("msg");
  el.textContent=text;
  el.className="status"+(err?" err":"");
  el.classList.remove("hidden");
  clearTimeout(msgTimer);
  msgTimer=setTimeout(()=>el.classList.add("hidden"),4500);
}
function showBanner(text){
  const el=$("banner"); el.textContent=text; el.classList.remove("hidden");
}
function hideBanner(){ $("banner").classList.add("hidden"); }

async function pickFolder(){
  if(!window.showDirectoryPicker){
    showBanner("当前浏览器不支持本地文件夹编辑。请使用新版 Chrome / Edge。");
    return;
  }
  try{
    dirHandle = await window.showDirectoryPicker({mode:"readwrite"});
    const ok = await verifyProjectFolder();
    if(!ok){
      dirHandle=null;
      showBanner("这个文件夹不是 UHTCEARE 项目根目录：没有找到 data/entries.json。");
      return;
    }
    await loadProject();
    $("folderName").textContent = "已打开：" + (dirHandle.name || "项目");
    hideBanner();
    renderList();
    applyQuery();
    showMsg("项目已打开，可以直接编辑；不需要运行 Node 服务器。");
  }catch(e){
    if(e && e.name !== "AbortError") showMsg("打开项目失败：" + e.message, true);
  }
}

async function verifyProjectFolder(){
  try{
    const data = await readText(["data","entries.json"]);
    JSON.parse(data);
    return true;
  }catch(e){ return false; }
}
async function getDir(parts, create=false){
  let h=dirHandle;
  for(const p of parts) h=await h.getDirectoryHandle(p,{create});
  return h;
}
async function readText(parts){
  let h=dirHandle;
  for(let i=0;i<parts.length-1;i++) h=await h.getDirectoryHandle(parts[i]);
  const f=await h.getFileHandle(parts[parts.length-1]);
  return await (await f.getFile()).text();
}
async function writeText(parts,text){
  let h=dirHandle;
  for(let i=0;i<parts.length-1;i++) h=await h.getDirectoryHandle(parts[i],{create:true});
  const f=await h.getFileHandle(parts[parts.length-1],{create:true});
  const w=await f.createWritable(); await w.write(text); await w.close();
}
async function writeBytes(parts,blob){
  let h=dirHandle;
  for(let i=0;i<parts.length-1;i++) h=await h.getDirectoryHandle(parts[i],{create:true});
  const f=await h.getFileHandle(parts[parts.length-1],{create:true});
  const w=await f.createWritable(); await w.write(blob); await w.close();
}
async function removeFile(parts){
  let h=dirHandle;
  for(let i=0;i<parts.length-1;i++) h=await h.getDirectoryHandle(parts[i]);
  try{ await h.removeEntry(parts[parts.length-1]); }catch(e){}
}

async function loadProject(){
  entries=JSON.parse(await readText(["data","entries.json"]));
  if(!Array.isArray(entries)) entries=[];
}
async function saveProject(){
  await writeText(["data","entries.json"],JSON.stringify(entries,null,2));
  await writeText(["assets","data.js"],makeDataJs(entries));
  for(const e of entries) await writeArticle(e);
}
function makeDataJs(list){
  let s="var SITE_ENTRIES = [\n";
  for(const e of list){
    const o={id:e.id,cat:e.cat,date:e.date,title:e.title,href:"content/"+e.id+".html",summary:e.summary||""};
    if(e.album){
      o.album=(e.album.artist||"")+" / "+(e.album.title||"");
      o.info=(e.album.year||"")+(e.album.genre?" / "+e.album.genre:"");
      o.rating=e.album.rating||"";
      if(e.cover)o.cover=e.cover;
    }
    if(e.listen&&e.listen.length)o.listen=e.listen;
    s+="  "+JSON.stringify(o).replace(/</g,"\\u003c")+",\n";
  }
  s+="];\nvar SITE_CATS = "+JSON.stringify(CAT_NAMES)+";\n";
  return s;
}
function renderBody(text){
  return String(text||"").split(/\n\s*\n/).filter(p=>p.trim()).map(p=>{
    const html=esc(p).replace(/\n/g,"<br>").replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2">$1</a>');
    return "<p>"+html+"</p>";
  }).join("");
}
async function writeArticle(e){
  const nav='<a href="../journal.html">journal</a><a href="../notes.html">notes</a><a href="../novel.html">novel</a><a href="../photographs.html">photographs</a><br>\n<a href="../music.html">music</a><a href="../index.html">index</a><a href="../search.html">search</a><a href="../random.html">random</a>';
  let out='<p class="meta">'+esc(e.date)+" · "+esc(e.cat)+'</p>';
  out+='<div class="title-row"><h1>'+esc(e.title)+'</h1><a class="title-add" href="../edit.html?id='+encodeURIComponent(e.id)+'&add=1">+ add</a></div>';
  if(e.album){
    out+='<p class="meta">'+esc(e.album.artist||"")+" / "+esc(e.album.title||"")+"<br>"+esc((e.album.year||"")+(e.album.genre?" / "+e.album.genre:""))+"<br>"+esc(e.album.rating||"")+"</p>";
    if(e.cover) out+='<img class="cover" src="'+esc(e.cover)+'" alt="'+esc(e.album.title||"cover")+'">';
  }
  out+=renderBody(e.body);
  if(e.listen&&e.listen.length) out+="<p>listen:<br>"+e.listen.map(l=>'<span class="listen"><a href="'+esc(l.url)+'">'+esc(l.label)+"</a></span> ").join("")+"</p>";
  if(e.images&&e.images.length) out+='<div class="gallery">'+e.images.map(im=>'<img src="'+esc(im)+'" alt="">').join("")+"</div>";
  out+='<p><a class="backlink" href="../'+esc(e.cat)+'.html">← '+esc(e.cat)+'</a> · <a class="backlink" href="../edit.html?id='+encodeURIComponent(e.id)+'">edit</a></p>';
  const html='<!doctype html>\n<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>'+esc(e.title)+' - UHTCEARE</title>\n<link rel="stylesheet" href="../assets/style.css">\n</head>\n<body>\n<div class="outer">\n<header class="toolbar">\n<div class="site-name"><a href="../index.html">UHTCEARE</a></div>\n<hr>\n<nav class="nav">\n'+nav+'\n</nav>\n</header>\n<main class="content">\n<article class="prose">\n'+out+'\n</article>\n</main>\n<footer class="footer">UHTCEARE — local editor · <a href="../edit.html">edit</a></footer>\n</div>\n</body>\n</html>\n';
  await writeText(["content",e.id+".html"],html);
}

function sortEntries(){return entries.slice().sort((a,b)=>a.date<b.date?1:-1)}
function renderList(){
  const q=($("filter")?.value||"").toLowerCase();
  const cat=$("filterCat")?.value||"";
  let out="";
  sortEntries().filter(e=>(!cat||e.cat===cat)&&(!q||(e.title+" "+e.summary).toLowerCase().includes(q))).forEach(e=>{
    out+='<div class="admin-row"><span class="tag">'+esc(e.date)+'</span> <span class="tag">'+esc(e.cat)+'</span> '+esc(e.title)+
      ' <button data-act="edit" data-id="'+esc(e.id)+'">edit</button> <button data-act="del" data-id="'+esc(e.id)+'">delete</button></div>';
  });
  $("list").innerHTML=out||'<p class="hint">没有符合条件的条目。</p>';
}
function syncCat(){
  const c=$("f-cat").value;
  $("musicfields").classList.toggle("hidden",c!=="music");
  $("coverfield").classList.toggle("hidden",c!=="music");
  $("photofield").classList.toggle("hidden",c!=="photographs");
}
function newForm(cat){
  current=null; selectedCover=null; selectedPhotos=[];
  $("formsec").classList.remove("hidden");
  $("formtitle").textContent="new entry";
  ["f-title","f-summary","f-body","f-artist","f-album","f-year","f-genre","f-listen"].forEach(id=>$(id).value="");
  $("f-date").value=new Date().toISOString().slice(0,10);
  $("f-cat").value=cat||"journal"; $("f-rating").value="☆";
  $("fileCover").value=""; $("filePhotos").value="";
  $("coverprev").innerHTML='<span class="hint">暂无封面</span>';
  $("photoprev").innerHTML='<span class="hint">暂无照片</span>';
  syncCat(); $("formsec").scrollIntoView();
}
function openForm(e){
  current=e; selectedCover=null; selectedPhotos=[];
  $("formsec").classList.remove("hidden");
  $("formtitle").textContent="edit: "+e.title;
  $("f-title").value=e.title; $("f-date").value=e.date; $("f-cat").value=e.cat;
  $("f-summary").value=e.summary||""; $("f-body").value=e.body||"";
  $("f-artist").value=e.album?.artist||""; $("f-album").value=e.album?.title||"";
  $("f-year").value=e.album?.year||""; $("f-genre").value=e.album?.genre||"";
  $("f-rating").value=e.album?.rating||"☆";
  $("f-listen").value=(e.listen||[]).map(l=>l.label+"|"+l.url).join("\n");
  $("fileCover").value=""; $("filePhotos").value="";
  renderCover(e.cover||""); renderPhotos(e.images||[]); syncCat(); $("formsec").scrollIntoView();
}
function gather(){
  const e={id:current?.id||"",cat:$("f-cat").value,date:$("f-date").value,title:$("f-title").value.trim(),summary:$("f-summary").value.trim(),body:$("f-body").value};
  if(e.cat==="music"){
    e.album={artist:$("f-artist").value.trim(),title:$("f-album").value.trim(),year:$("f-year").value.trim(),genre:$("f-genre").value.trim(),rating:$("f-rating").value};
    e.listen=$("f-listen").value.split("\n").map(x=>x.trim()).filter(Boolean).map(x=>{const p=x.split("|");return {label:(p[0]||"").trim(),url:(p[1]||"").trim()};}).filter(x=>x.label&&x.url);
  }
  e.cover=current?.cover||"";
  e.images=current?.images||[];
  return e;
}
function slugify(s){return String(s||"").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g,"-").replace(/^-+|-+$/g,"")||"entry";}
function uniqueId(base){
  let id=base,n=2;
  while(entries.some(e=>e.id===id)){id=base+"-"+n++;}
  return id;
}
async function save(){
  if(!dirHandle){showMsg("请先打开 UHTCEARE 项目文件夹。",true);return;}
  const e=gather();
  if(!e.title||!e.date){showMsg("标题和日期必填。",true);return;}
  if(!e.id)e.id=uniqueId(e.date+"-"+slugify(e.title));
  const idx=entries.findIndex(x=>x.id===e.id);
  if(idx<0) entries.push(e); else entries[idx]=e;
  try{
    await saveProject(); current=e; renderList(); openForm(e);
    showMsg("已保存："+e.title);
  }catch(err){showMsg("保存失败："+err.message,true);}
}
async function del(id){
  if(!dirHandle)return;
  const e=entries.find(x=>x.id===id); if(!e)return;
  if(!confirm("删除 "+e.title+"？文章页与关联图片也会删除。"))return;
  try{
    await removeFile(["content",e.id+".html"]);
    for(const im of [e.cover,...(e.images||[])].filter(Boolean)) await removeFile(["content",...im.split("/")]);
    entries=entries.filter(x=>x.id!==id); await saveProject();
    $("formsec").classList.add("hidden"); renderList(); showMsg("已删除："+e.title);
  }catch(err){showMsg("删除失败："+err.message,true);}
}
function renderCover(cover){
  $("coverprev").innerHTML=cover?'<img class="upimg" src="content/'+esc(cover)+'" alt="cover"> <button data-act="delcover">删除封面</button>':'<span class="hint">暂无封面</span>';
}
function renderPhotos(images){
  $("photoprev").innerHTML=images.length?images.map(im=>'<span><img class="upimg" src="content/'+esc(im)+'" alt=""> <button data-act="delimg" data-path="'+esc(im)+'">x</button></span> ').join(""):'<span class="hint">暂无照片</span>';
}
async function uploadCover(file){
  if(!current||!dirHandle)return;
  const ext="."+file.name.split(".").pop().toLowerCase();
  if(![".jpg",".jpeg",".png",".gif",".webp"].includes(ext)){showMsg("不支持这种图片格式。",true);return;}
  const fname=current.id+"-cover"+ext, stored="music/covers/"+fname;
  if(current.cover&&current.cover!==stored)await removeFile(["content",...current.cover.split("/")]);
  await writeBytes(["content","music","covers",fname],file);
  current.cover=stored; entries[entries.findIndex(x=>x.id===current.id)]=current;
  await saveProject(); renderCover(stored); renderList(); showMsg("封面已上传。");
}
async function uploadPhotos(files){
  if(!current||!dirHandle)return;
  for(const file of files){
    const ext="."+file.name.split(".").pop().toLowerCase();
    if(![".jpg",".jpeg",".png",".gif",".webp"].includes(ext))continue;
    const fname=current.id+"-"+Date.now()+"-"+slugify(file.name.replace(/\.[^.]+$/,""))+ext;
    const stored="photographs/"+fname;
    await writeBytes(["content","photographs",fname],file);
    if(!current.images)current.images=[];
    current.images.push(stored);
  }
  entries[entries.findIndex(x=>x.id===current.id)]=current;
  await saveProject(); renderPhotos(current.images); renderList(); showMsg("照片已上传。");
}
async function deleteImage(path){
  if(!current)return;
  await removeFile(["content",...path.split("/")]);
  current.cover=current.cover===path?"":current.cover;
  current.images=(current.images||[]).filter(x=>x!==path);
  entries[entries.findIndex(x=>x.id===current.id)]=current;
  await saveProject(); renderCover(current.cover); renderPhotos(current.images); renderList();
}
function applyQuery(){
  const p=new URLSearchParams(location.search);
  if(p.get("id")){
    const e=entries.find(x=>x.id===p.get("id")); if(e)openForm(e);
  }else if(p.get("new")==="1")newForm(p.get("cat")||"journal");
}

document.addEventListener("click",async ev=>{
  const t=ev.target;if(t.tagName!=="BUTTON")return;
  const a=t.dataset.act;
  if(t.id==="openbtn"){pickFolder();return}
  if(t.id==="newbtn"){newForm($("filterCat").value||"journal");return}
  if(t.id==="savebtn"){await save();return}
  if(t.id==="cancelbtn"){$("formsec").classList.add("hidden");return}
  if(a==="edit"){const e=entries.find(x=>x.id===t.dataset.id);if(e)openForm(e);return}
  if(a==="del"){await del(t.dataset.id);return}
  if(a==="delcover"){await deleteImage(current.cover);return}
  if(a==="delimg"){await deleteImage(t.dataset.path);return}
});
$("f-cat").addEventListener("change",syncCat);
$("fileCover").addEventListener("change",e=>{if(e.target.files[0])uploadCover(e.target.files[0]);});
$("filePhotos").addEventListener("change",e=>{if(e.target.files.length)uploadPhotos(e.target.files);});
$("filter").addEventListener("input",renderList);
$("filterCat").addEventListener("change",renderList);
$("folderName").textContent="尚未打开项目";
