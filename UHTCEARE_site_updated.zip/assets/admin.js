var current = null;
var msgTimer = null;

function $(id){ return document.getElementById(id); }
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function msg(t, type){
  var el = $("msg");
  el.innerHTML = t;
  el.className = "status" + (type === "err" ? " err" : "");
  el.classList.remove("hidden");
  if(msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(function(){ el.classList.add("hidden"); }, 4000);
}

function fail(t){
  var b = $("banner");
  b.textContent = t;
  b.classList.remove("hidden");
}

function api(url, opts){
  return fetch(url, opts).then(function(r){ return r.json(); }, function(){ throw new Error("offline"); });
}

function offline(){
  fail("无法连接服务器。编辑功能需要先运行 start-server.bat（或 node server.js），然后访问 http://localhost:8080/edit.html");
}

function renderList(list){
  var out = "";
  list.slice().sort(function(a,b){ return a.date < b.date ? 1 : -1; }).forEach(function(e){
    var flag = "";
    if(e.cat === "music" && e.cover) flag += " [cover]";
    if(e.cat === "photographs" && e.images && e.images.length) flag += " [" + e.images.length + " img]";
    out += '<div class="admin-row"><span class="tag">' + esc(e.date) + '</span> <span class="tag">' + esc(e.cat) + '</span> ' + esc(e.title) + flag +
           ' <button type="button" data-act="edit" data-id="' + esc(e.id) + '">edit</button>' +
           ' <button type="button" data-act="del" data-id="' + esc(e.id) + '">delete</button></div>';
  });
  $("list").innerHTML = out || '<p class="hint">还没有条目。</p>';
}

function load(){
  api("/api/entries").then(function(list){
    renderList(list);
    var id = new URLSearchParams(location.search).get("id");
    var addMode = new URLSearchParams(location.search).get("add") === "1";
    if(id){
      var e = list.find(function(x){ return x.id === id; });
      if(e){
        openForm(e);
        if(addMode){
          var tb = $("f-body");
          tb.focus();
          tb.setSelectionRange(tb.value.length, tb.value.length);
          msg('正在编辑：<a href="content/' + esc(e.id) + '.html">' + esc(e.title) + '</a> — 可直接在正文中继续添加内容');
        }
      }
    }
  }).catch(function(){ offline(); });
}

function openForm(e){
  current = e;
  $("formsec").classList.remove("hidden");
  $("formtitle").textContent = "edit: " + e.title;
  $("f-title").value = e.title;
  $("f-date").value = e.date;
  $("f-cat").value = e.cat;
  $("f-summary").value = e.summary;
  $("f-body").value = e.body || "";
  $("f-artist").value = e.album ? e.album.artist : "";
  $("f-album").value = e.album ? e.album.title : "";
  $("f-year").value = e.album ? e.album.year : "";
  $("f-genre").value = e.album ? e.album.genre : "";
  $("f-rating").value = e.album ? e.album.rating : "☆☆☆☆☆";
  $("f-listen").value = (e.listen||[]).map(function(l){ return l.label + "|" + l.url; }).join("\n");
  syncCat();
  renderCover(e.cover);
  renderPhotos(e.images||[]);
  $("formsec").scrollIntoView();
}

function newForm(){
  current = null;
  $("formsec").classList.remove("hidden");
  $("formtitle").textContent = "new entry";
  ["f-title","f-date","f-summary","f-body","f-artist","f-album","f-year","f-genre","f-listen"].forEach(function(id){ $(id).value = ""; });
  $("f-date").value = new Date().toISOString().slice(0,10);
  $("f-cat").value = "journal";
  $("f-rating").value = "☆☆☆☆☆";
  syncCat();
  renderCover("");
  renderPhotos([]);
  $("formsec").scrollIntoView();
}

function syncCat(){
  var m = $("f-cat").value === "music";
  $("musicfields").classList.toggle("hidden", !m);
  $("coverfield").classList.toggle("hidden", !m);
  $("photofield").classList.toggle("hidden", m);
  $("photofield").classList.toggle("hidden", $("f-cat").value !== "photographs");
}

function gather(){
  var e = {
    id: current ? current.id : "",
    cat: $("f-cat").value,
    date: $("f-date").value,
    title: $("f-title").value.trim(),
    summary: $("f-summary").value.trim(),
    body: $("f-body").value
  };
  if(e.cat === "music"){
    e.album = {artist:$("f-artist").value.trim(), title:$("f-album").value.trim(), year:$("f-year").value.trim(), genre:$("f-genre").value.trim(), rating:$("f-rating").value};
    e.listen = $("f-listen").value.split("\n").map(function(l){ return l.trim(); }).filter(Boolean).map(function(l){
      var p = l.split("|");
      return {label:p[0].trim(), url:(p[1]||"").trim()};
    }).filter(function(l){ return l.label && l.url; });
  }
  return e;
}

function save(){
  var e = gather();
  if(!e.title || !e.date){ msg("标题和日期必填", "err"); return; }
  api("/api/entries", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(e)}).then(function(saved){
    if(saved.error){ msg(saved.error, "err"); return; }
    current = saved;
    msg('已保存：<a href="content/' + esc(saved.id) + '.html">' + esc(saved.title) + '</a>');
    load();
  }).catch(function(){ offline(); });
}

function del(id){
  if(!confirm("删除 " + id + " ？其文章页与图片也会被删除。")) return;
  api("/api/entries?id=" + encodeURIComponent(id), {method:"DELETE"}).then(function(r){
    if(r.error){ msg(r.error, "err"); return; }
    msg("已删除：" + id);
    $("formsec").classList.add("hidden");
    load();
  }).catch(function(){ offline(); });
}

function renderCover(cover){
  $("coverprev").innerHTML = cover ? '<img class="upimg" src="content/' + esc(cover) + '" alt="cover"> <button type="button" data-act="delcover">删除封面</button>' : '<span class="hint">暂无封面</span>';
}

function renderPhotos(images){
  var out = images.map(function(im){
    return '<span><img class="upimg" src="content/' + esc(im) + '" alt=""> <button type="button" data-act="delimg" data-path="' + esc(im) + '">x</button></span> ';
  }).join("");
  $("photoprev").innerHTML = out || '<span class="hint">暂无照片</span>';
}

function upload(file, cat, done){
  var r = new FileReader();
  r.onload = function(){
    var data = String(r.result).split(",")[1];
    api("/api/upload", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({cat:cat, id:current.id, name:file.name, data:data})}).then(function(r2){
      if(r2.error){ msg(r2.error); return; }
      current = r2.entry;
      if(cat === "music"){ renderCover(current.cover); msg("已上传封面：" + esc(file.name)); }
      else { renderPhotos(current.images); msg("已上传照片：" + esc(file.name)); }
      load();
    }).catch(function(){ offline(); });
  };
  r.readAsDataURL(file);
}

function delImage(path){
  api("/api/delete-image", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:current.id, path:path})}).then(function(r){
    if(r.error){ msg(r.error, "err"); return; }
    current = r.entry;
    if(r.entry.cover === "") renderCover("");
    renderPhotos(current.images);
    msg("已删除图片");
    load();
  }).catch(function(){ offline(); });
}

document.addEventListener("click", function(ev){
  var t = ev.target;
  if(t.id === "newbtn"){ newForm(); return; }
  if(t.id === "savebtn"){ save(); return; }
  if(t.id === "cancelbtn"){ $("formsec").classList.add("hidden"); return; }
  if(t.tagName !== "BUTTON") return;
  var act = t.getAttribute("data-act");
  if(act === "edit"){ api("/api/entries").then(function(list){ openForm(list.find(function(x){ return x.id === t.getAttribute("data-id"); })); }).catch(function(){ offline(); }); }
  if(act === "del"){ del(t.getAttribute("data-id")); }
  if(act === "delcover"){ delImage(current.cover); }
  if(act === "delimg"){ delImage(t.getAttribute("data-path")); }
});

$("f-cat").addEventListener("change", syncCat);
$("f-cover").addEventListener("change", function(){
  if(!current){ msg("先保存条目"); return; }
  if(this.files.length) upload(this.files[0], "music");
});
$("f-photos").addEventListener("change", function(){
  if(!current){ msg("先保存条目"); return; }
  Array.prototype.forEach.call(this.files, function(f){ upload(f, "photographs"); });
});

if(location.protocol === "file:"){
  fail("当前是以文件方式直接打开（file:// 协议）。编辑功能必须通过服务器使用：双击 start-server.bat，然后访问 http://localhost:8080/edit.html");
} else {
  load();
}