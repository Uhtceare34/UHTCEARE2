function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}

function sorted(){return SITE_ENTRIES.slice().sort(function(a,b){return a.date<b.date?1:-1})}

function catName(c){return c}

function renderCategoryList(id, cat){
  var el=document.getElementById(id);
  if(!el)return;
  var out="";
  sorted().forEach(function(e){
    if(e.cat!==cat)return;
    out+='<p class="entry"><span class="date">'+esc(e.date)+'</span><a class="title" href="'+esc(e.href)+'">'+esc(e.title)+'</a><span class="preview">'+esc(e.summary)+'</span></p>';
  });
  el.innerHTML=out;
}

function renderMusicList(id){
  var el=document.getElementById(id);
  if(!el)return;
  var out="";
  sorted().forEach(function(e){
    if(e.cat!=="music")return;
    var lk="";
    (e.listen||[]).forEach(function(l){
      lk+='<span class="listen"><a href="'+esc(l.url)+'">'+esc(l.label)+'</a></span> ';
    });
    var thumb=e.cover?'<img class="thumb" src="content/'+esc(e.cover)+'" alt="">':'';
    out+='<p class="entry"><span class="date">'+esc(e.date)+'</span><a class="title" href="'+esc(e.href)+'">'+esc(e.title)+'</a><span class="preview">'+thumb+esc(e.album)+' · '+esc(e.info)+' · '+esc(e.rating)+'<br>'+esc(e.summary)+'<br>listen: '+lk+'</span></p>';
  });
  el.innerHTML=out;
}

function renderTimeline(id){
  var el=document.getElementById(id);
  if(!el)return;
  var year="";
  var day="";
  var out="";
  sorted().forEach(function(e){
    if(e.date.slice(0,4)!==year){
      year=e.date.slice(0,4);
      day="";
      out+='<div class="timeline-year">'+esc(year)+'</div>';
    }
    var d=e.date.slice(5);
    if(d!==day){
      day=d;
      out+='<div class="timeline-day">'+esc(d)+'</div>';
    }
    out+='<div class="timeline-item"><a href="'+esc(e.href)+'">'+esc(e.title)+'</a><span class="tag">'+esc(e.cat)+'</span></div>';
  });
  el.innerHTML=out;
}

function initSearch(){
  var input=document.getElementById("q");
  var res=document.getElementById("results");
  if(!input||!res)return;
  function run(){
    var q=input.value.toLowerCase().trim();
    var out="";
    if(q===""){
      res.innerHTML='<p class="entry"><span class="date">—</span>输入关键词开始搜索（标题 / 摘要 / 类别）。</p>';
      return;
    }
    sorted().forEach(function(e){
      var hay=(e.title+" "+e.summary+" "+e.cat+" "+e.album).toLowerCase();
      if(hay.indexOf(q)===-1)return;
      out+='<p class="entry"><span class="date">'+esc(e.date)+'</span><a class="title" href="'+esc(e.href)+'">'+esc(e.title)+'</a><span class="tag">'+esc(e.cat)+'</span><span class="preview">'+esc(e.summary)+'</span></p>';
    });
    if(out==="")out='<p class="entry"><span class="date">—</span>没有找到匹配的内容。</p>';
    res.innerHTML=out;
  }
  input.addEventListener("input",run);
  run();
}

function initRandom(){
  var box=document.getElementById("randbox");
  var btn=document.getElementById("randbtn");
  if(!box||!btn)return;
  function pick(){
    var e=sorted()[Math.floor(Math.random()*SITE_ENTRIES.length)];
    var lk="";
    (e.listen||[]).forEach(function(l){
      lk+='<span class="listen"><a href="'+esc(l.url)+'">'+esc(l.label)+'</a></span> ';
    });
    box.innerHTML='<p class="entry"><span class="date">'+esc(e.date)+'</span><a class="title" href="'+esc(e.href)+'">'+esc(e.title)+'</a><span class="tag">'+esc(e.cat)+'</span><span class="preview">'+esc(e.summary)+(lk?'<br>listen: '+lk:'')+'</span></p>';
  }
  btn.addEventListener("click",pick);
  pick();
}
