var SITE_ENTRIES = [
  {"id":"2026-08-20-一次联想","cat":"journal","date":"2026-08-20","title":"一次联想","href":"content/2026-08-20-一次联想.html","summary":"无聊的事情，然而却让我感兴趣，换做是其它人会感兴趣吗"},
  {"id":"2026-08-20-6662","cat":"music","date":"2026-08-20","title":"6662","href":"content/2026-08-20-6662.html","summary":"3453","album":" / ","info":"","rating":"★☆","cover":"music/covers/2026-08-20-6662-129666435-p0.jpg"},
];
var SITE_CATS = {journal:"我今天发生了什么。",notes:"我刚刚想到什么。",novel:"我创造了什么。",photographs:"我看见了什么。",music:"我听见了什么，以及我如何理解它。"};
