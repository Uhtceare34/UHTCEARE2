# UHTCEARE

个人文字 / 小说 / 摄影 / 音乐记录站。

## 在线访问

项目本身是纯静态网站，可直接部署到 GitHub Pages。

## 本地编辑

现在不需要运行 `node server.js` 才能编辑。

1. 用新版 Chrome 或 Edge 打开 `edit.html`。
2. 点击“打开 UHTCEARE 项目”。
3. 选择本项目根目录。
4. 在各个板块点击 `+ new`，或在文章页点击 `+ add`。
5. 保存后，编辑器会直接更新：
   - `data/entries.json`
   - `assets/data.js`
   - `content/*.html`
   - 图片文件

然后把修改后的文件提交到 GitHub，GitHub Pages 会自动重新部署。

`server.js` 仍然保留，作为旧版本地服务器和兼容方式；新的本地编辑流程不依赖它。

## GitHub Pages

仓库包含 `.github/workflows/pages.yml`。将仓库默认分支设为 `main`，并在 GitHub 的 Pages 设置中选择 **GitHub Actions** 作为构建方式即可。
