@echo off
cd /d "%~dp0"
echo UHTCEARE starting at http://localhost:8080
echo (press Ctrl+C to stop)
node server.js
pause