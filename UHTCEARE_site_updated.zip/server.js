var http = require("http");
var fs = require("fs");
var path = require("path");

var ROOT = __dirname;
var DATA_DIR = path.join(ROOT, "data");
var DATA_FILE = path.join(DATA_DIR, "entries.json");
var DATAJS_FILE = path.join(ROOT, "assets", "data.js");
var CONTENT_DIR = path.join(ROOT, "content");
var MUSIC_COVER_DIR = path.join(CONTENT_DIR, "music", "covers");
var PHOTO_DIR = path.join(CONTENT_DIR, "photographs");

var MIME = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png",".gif":"image/gif",".webp":"image/webp",".ico":"image/x-icon",".svg":"image/svg+xml",".txt":"text/plain; charset=utf-8"};
var IMG_EXT = [".jpg",".jpeg",".png",".gif",".webp"];

function ensureDirs(){
  [DATA_DIR, MUSIC_COVER_DIR, PHOTO_DIR].forEach(function(d){ if(!fs.existsSync(d)) fs.mkdirSync(d, {recursive:true}); });
}

function loadEntries(){
  if(!fs.existsSync(DATA_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); } catch(e){ return []; }
}

function saveEntries(list){
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2), "utf8");
  writeDataJs(list);
}

function jsStr(x){ return JSON.stringify(x).replace(/</g, "\\u003c"); }

function writeDataJs(list){
  var s = "var SITE_ENTRIES = [\n";
  list.forEach(function(e){
    var o = {id:e.id, cat:e.cat, date:e.date, title:e.title, href:"content/"+e.id+".html", summary:e.summary};
    if(e.album){
      o.album = (e.album.artist||"") + " / " + (e.album.title||"");
      o.info = (e.album.year||"") + (e.album.genre ? " / " + e.album.genre : "");
      o.rating = e.album.rating||"";
      if(e.cover) o.cover = e.cover;
    }
    if(e.listen && e.listen.length) o.listen = e.listen;
    s += "  " + jsStr(o) + ",\n";
  });
  s += "];\nvar SITE_CATS = {journal:\"我今天发生了什么。\",notes:\"我刚刚想到什么。\",novel:\"我创造了什么。\",photographs:\"我看见了什么。\",music:\"我听见了什么，以及我如何理解它。\"};\n";
  fs.writeFileSync(DATAJS_FILE, s, "utf8");
}

function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function renderBody(text){
  return String(text||"").split(/\n\s*\n/).filter(function(p){ return p.trim()!==""; }).map(function(p){
    var html = esc(p).replace(/\n/g, "<br>").replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    return "<p>" + html + "</p>";
  }).join("");
}

function writeArticle(e){
  var nav = '<a href="../journal.html">journal</a><a href="../notes.html">notes</a><a href="../novel.html">novel</a><a href="../photographs.html">photographs</a><br>\n<a href="../music.html">music</a><a href="../index.html">index</a><a href="../search.html">search</a><a href="../random.html">random</a>';
  var out = "";
  out += '<p class="meta">' + esc(e.date) + " · " + esc(e.cat) + "</p>";
  out += '<div class="title-row"><h1>' + esc(e.title) + '</h1><a class="title-add" href="../edit.html?id=' + encodeURIComponent(e.id) + '&add=1">+ add</a></div>';
  if(e.album){
    out += '<p class="meta">' + esc(e.album.artist||"") + " / " + esc(e.album.title||"") + "<br>" + esc((e.album.year||"") + (e.album.genre ? " / " + e.album.genre : "")) + "<br>" + esc(e.album.rating||"") + "</p>";
    if(e.cover) out += '<img class="cover" src="' + esc(e.cover) + '" alt="' + esc(e.album.title||"cover") + '">';
  }
  out += renderBody(e.body);
  if(e.listen && e.listen.length){
    out += "<p>listen:<br>" + e.listen.map(function(l){ return '<span class="listen"><a href="' + esc(l.url) + '">' + esc(l.label) + "</a></span> "; }).join("") + "</p>";
  }
  if(e.images && e.images.length){
    out += '<div class="gallery">' + e.images.map(function(im){ return '<img src="' + esc(im) + '" alt="">'; }).join("") + "</div>";
  }
  out += '<p><a class="backlink" href="../' + esc(e.cat) + '.html">← ' + esc(e.cat) + '</a> · <a class="backlink" href="../edit.html?id=' + encodeURIComponent(e.id) + '">edit</a></p>';
  var html = '<!doctype html>\n<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>' + esc(e.title) + ' - UHTCEARE</title>\n<link rel="stylesheet" href="../assets/style.css">\n</head>\n<body>\n<div class="outer">\n<header class="toolbar">\n<div class="site-name"><a href="../index.html">UHTCEARE</a></div>\n<hr>\n<nav class="nav">\n' + nav + '\n</nav>\n</header>\n<main class="content">\n<article class="prose">\n' + out + '\n</article>\n</main>\n<footer class="footer">UHTCEARE — last updated 2026.08.20 · <a href="../edit.html">edit</a></footer>\n</div>\n</body>\n</html>\n';
  fs.writeFileSync(path.join(CONTENT_DIR, e.id + ".html"), html, "utf8");
}

function regenAll(list){
  writeDataJs(list);
  list.forEach(writeArticle);
}

function slugify(s){
  return String(s||"").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, "-").replace(/^-+|-+$/g, "");
}

function sendJson(res, code, obj){
  var b = JSON.stringify(obj);
  res.writeHead(code, {"Content-Type":"application/json; charset=utf-8"});
  res.end(b);
}

function readBody(req, cb){
  var d = [];
  req.on("data", function(c){ d.push(c); });
  req.on("end", function(){ cb(Buffer.concat(d).toString("utf8")); });
}

function serveStatic(req, res){
  var url = req.url.split("?")[0];
  try { url = decodeURIComponent(url); } catch(e){}
  if(url === "/") url = "/index.html";
  var fp = path.normalize(path.join(ROOT, url));
  if(fp !== ROOT && !fp.startsWith(ROOT + path.sep)){ res.writeHead(403); res.end("forbidden"); return; }
  if(!fs.existsSync(fp) || fs.statSync(fp).isDirectory()){ res.writeHead(404); res.end("not found"); return; }
  var ext = path.extname(fp).toLowerCase();
  res.writeHead(200, {"Content-Type": MIME[ext] || "application/octet-stream", "Cache-Control": "no-cache"});
  fs.createReadStream(fp).pipe(res);
}

var server = http.createServer(function(req, res){
  try {
    var url = req.url.split("?")[0];
    if(url === "/api/entries"){
      if(req.method === "GET"){ sendJson(res, 200, loadEntries()); return; }
      if(req.method === "POST"){
        readBody(req, function(b){
          var e = JSON.parse(b);
          if(!e.title || !e.cat || !e.date){ sendJson(res, 400, {error:"title/cat/date required"}); return; }
          var list = loadEntries();
          var idx = list.findIndex(function(x){ return x.id === e.id; });
          if(idx === -1){
            if(!e.id) e.id = e.date + "-" + slugify(e.title);
            e.cover = ""; e.images = [];
            list.push(e);
          } else {
            var old = list[idx];
            e.cover = old.cover || "";
            e.images = old.images || [];
            list[idx] = e;
          }
          saveEntries(list);
          writeArticle(e);
          sendJson(res, 200, e);
        });
        return;
      }
      if(req.method === "DELETE"){
        var id = "";
        try { id = decodeURIComponent((req.url.split("?")[1]||"").replace(/^id=/,"")); } catch(e){}
        id = id.trim();
        var list = loadEntries();
        var idx = list.findIndex(function(x){ return x.id === id; });
        if(idx === -1){ sendJson(res, 404, {error:"not found"}); return; }
        var e = list[idx];
        try { if(fs.existsSync(path.join(CONTENT_DIR, id + ".html"))) fs.unlinkSync(path.join(CONTENT_DIR, id + ".html")); } catch(err){}
        [e.cover].concat(e.images||[]).forEach(function(im){
          if(!im) return;
          var fp = path.normalize(path.join(CONTENT_DIR, im));
          try { if(fp.startsWith(CONTENT_DIR) && fs.existsSync(fp)) fs.unlinkSync(fp); } catch(err){}
        });
        list.splice(idx, 1);
        saveEntries(list);
        sendJson(res, 200, {ok:true});
        return;
      }
    }
    if(url === "/api/upload"){
      if(req.method !== "POST"){ res.writeHead(405); res.end(); return; }
      readBody(req, function(b){
        var p = JSON.parse(b);
        var list = loadEntries();
        var e = list.find(function(x){ return x.id === p.id; });
        if(!e){ sendJson(res, 404, {error:"entry not found"}); return; }
        var ext = path.extname(p.name||"").toLowerCase();
        if(IMG_EXT.indexOf(ext) === -1){ sendJson(res, 400, {error:"unsupported image type"}); return; }
        var fname = e.id + "-" + slugify(path.basename(p.name, ext)) + ext;
        var stored = p.cat === "music" ? "music/covers/" + fname : "photographs/" + fname;
        var dir = p.cat === "music" ? MUSIC_COVER_DIR : PHOTO_DIR;
        if(!fs.existsSync(dir)) fs.mkdirSync(dir, {recursive:true});
        fs.writeFileSync(path.join(dir, fname), Buffer.from(p.data, "base64"));
        if(p.cat === "music"){
          if(e.cover && e.cover !== stored){
            try { fs.unlinkSync(path.join(CONTENT_DIR, e.cover)); } catch(err){}
          }
          e.cover = stored;
        } else {
          if(e.images.indexOf(stored) === -1) e.images.push(stored);
        }
        saveEntries(list);
        writeArticle(e);
        sendJson(res, 200, {ok:true, entry:e});
      });
      return;
    }
    if(url === "/api/delete-image"){
      if(req.method !== "POST"){ res.writeHead(405); res.end(); return; }
      readBody(req, function(b){
        var p = JSON.parse(b);
        var list = loadEntries();
        var e = list.find(function(x){ return x.id === p.id; });
        if(!e){ sendJson(res, 404, {error:"entry not found"}); return; }
        var fp = path.normalize(path.join(CONTENT_DIR, p.path));
        var musicDir = path.normalize(path.join(CONTENT_DIR, "music", "covers")) + path.sep;
        var photoDir = path.normalize(path.join(CONTENT_DIR, "photographs")) + path.sep;
        if(!fp.startsWith(musicDir) && !fp.startsWith(photoDir)){ sendJson(res, 400, {error:"bad path"}); return; }
        try { if(fs.existsSync(fp)) fs.unlinkSync(fp); } catch(err){}
        if(e.cover === p.path) e.cover = "";
        e.images = (e.images||[]).filter(function(im){ return im !== p.path; });
        saveEntries(list);
        writeArticle(e);
        sendJson(res, 200, {ok:true, entry:e});
      });
      return;
    }
    serveStatic(req, res);
  } catch(err){
    sendJson(res, 500, {error:String(err)});
  }
});

ensureDirs();

if(process.env.REGEN_ONLY){
  regenAll(loadEntries());
  console.log("articles regenerated");
  process.exit(0);
}

regenAll(loadEntries());

var port = parseInt(process.argv[2] || process.env.PORT || "8080", 10);
server.listen(port, function(){
  console.log("UHTCEARE running at http://localhost:" + port);
  console.log("edit page: http://localhost:" + port + "/edit.html");
});